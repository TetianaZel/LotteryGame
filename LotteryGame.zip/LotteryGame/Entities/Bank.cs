﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LotteryGame.Entities
{
    public class Bank
    {
        public decimal TotalRevenue { get; set; }
        public decimal TotalDistributedReward { get; set; }
        public decimal HouseProfit { get; set; }
    }
}
