﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LotteryGame.Enums
{
    public enum PrizeTier 
    {
        GrandPrize,
        SecondTier,
        ThirdTier
    }
}
